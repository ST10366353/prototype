package com.risparmio.budgetapp.data.model

data class QuizQuestion(
    val question: String,
    val answer: Boolean
)

