package com.risparmio.budgetapp.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.risparmio.budgetapp.R

class AchievementsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {//(android developpers,2025)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_achievements)


    }
}
