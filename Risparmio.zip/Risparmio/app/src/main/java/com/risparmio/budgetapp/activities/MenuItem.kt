package com.risparmio.budgetapp.activities

data class MenuItem(
    val emoji: String,
    val title: String,
    val subtitle: String
)
