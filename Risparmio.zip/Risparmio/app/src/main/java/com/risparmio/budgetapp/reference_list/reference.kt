package com.risparmio.budgetapp.reference_list

class reference {

     // android developers,2025,  Accessing data using Room DAOs, 10 February 2025, [online] available at:https://developer.android.com/training/data-storage/room/accessing-data
    //Android developers,2025 , the activity lifecycle, 10 February 2025 [online] available at:https://developer.android.com/guide/components/activities/activity-lifecycle
    // android knowledge, 2025, Easy Login Page in Android Studio using Kotlin – 5 Steps Only!, 2025 [online] available at:https://androidknowledge.com/loginpage-in-android-kotlin/
    //ghandi,2024, Kotlin Mutable List: Adding, Removing, and Updating Elements, dhiwise, 04 September 2024 [online] available at: https://www.dhiwise.com/post/kotlin-mutable-list-adding-removing-and-updating-elements
    //geeksforgeeks,2025 How to Add Image to Drawable Folder in Android Studio?, 06 January 2025, [online] available at:https://www.geeksforgeeks.org/how-to-add-image-to-drawable-folder-in-android-studio/
    //medium,2023,Simplifying Constraint Layout Constraints Programmatically, 1 October 2023 [online] available at:https://meet-miyani.medium.com/simplifying-constraint-layout-constraints-programmatically-91adf32e80f9
    //Pathel,2024, Understanding Kotlin Volatile and Its Role in Multithreading, 13 September 2024 [online] available at:https://www.dhiwise.com/post/understanding-kotlin-volatile-and-its-role-in-multithreading
    //random code,2022 Kotlin - How to create a Button and set up onClick, 05 October 2022 [online] available at:https://www.youtube.com/watch?v=r1P7slDbtd4

    //
}