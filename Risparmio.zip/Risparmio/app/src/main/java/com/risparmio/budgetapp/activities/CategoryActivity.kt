package com.risparmio.budgetapp.activities

class CategoryActivity {
}