package com.risparmio.budgetapp.data.model

data class CategoryStat(
    val name: String,
    val amount: Double // Correct for calculations
)
